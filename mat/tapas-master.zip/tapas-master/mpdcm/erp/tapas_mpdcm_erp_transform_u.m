function [nu] = tapas_mpdcm_erp_transform_u(u)
%% 
%
% Input
%
% Output
%

% aponteeduardo@gmail.com
% copyright (C) 2016
%

nu = cell(size(u));


for i = 1:numel(u)
    nu{i} =     
end



end % tapas_mpdcm_erp_transform_u 

