MCMC Diagnostics Toolbox for Matlab 6.x

Copyright (C) 1999 Simo S�rkk� <ssarkka@lce.hut.fi>
Copyright (C) 2000-2004 Aki Vehtari <Aki.Vehtari@hut.fi>
Maintainer: Aki Vehtari <Aki.Vehtari@hut.fi>

In 1999 Simo S�rkk� implemented several MCMC diagnostics in Matlab
at Helsinki University of Technology, Laboratory of Computational
Engineering <http://www.lce.hut.fi>. Later Aki Vehtari added a few
additonal utilities, fixed bugs and improved the documentation.

This software is distributed under the GNU General Public Licence
(version 2 or later); please refer to the file Licence.txt,
included with the software, for details.
