function [ntheta, ny, nllh, nlpp] = tapas_mpdcm_fmri_sample_metropolis(y, ...
    u, theta, ptheta, pars, oy, ollh, olpp)
%% 
%
% aponteeduardo@gmail.com
% copyright (C) 2016
%





end

