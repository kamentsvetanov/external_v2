% Sigmoid function.
function b = sigm(a)
    b = 1./(1+exp(-a));
end
