function tapas_print_logo()
%% Print the logo of tapas.

%
% aponteeduardo@gmail.com
% copyright (C) 2017
%

disp( '_________          _____                _____       _____           ____                ');
disp( '   |              |     |              |_____|     |     |         |                    ');
disp( '   |              |-----|              |           |-----|          ----|               ');
disp(['   | RANSLATIONAL |     |LGORITHMS for |sychiatry  |     |dvancing  ____|cience         ','']);
fprintf('\n');

end
