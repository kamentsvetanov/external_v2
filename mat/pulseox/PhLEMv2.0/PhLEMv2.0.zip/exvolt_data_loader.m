function data = exvolt_data_loader(input_file);

% function data = exvolt_data_loader(input_file);
%
% A loader function for output from the Exvolt Script.
%
% INPUT: 
% input_file = pointer to output file from exvolt log
%
% OUTPUT
% data       = vector of data signal
%
% Written by T. Verstynen (November 2007);
%
% Liscensed under the GPL public license (version 3.0)


% Just use DLMREAD
data = dlmread(input_file,'\t',9,0);
