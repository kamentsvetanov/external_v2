% figure098a - Calculate and plot equivalent D(4) wavelet and scaling filters.
% 
% Usage:
%   figure098a
%

% $Id: figure098a.m 303 2004-03-25 23:40:38Z ccornish $

plot_equivalent_filter('DWT', 'd6', 7);

figure_datestamp(mfilename, gcf);
