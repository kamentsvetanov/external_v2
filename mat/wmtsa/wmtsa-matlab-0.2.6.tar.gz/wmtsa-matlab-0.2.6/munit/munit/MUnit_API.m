%****m* munit/MUnit-API
% NAME
%   MUnit-API -- MUnit Application Programming Interface
%
% DESCRIPTION
%   The MUnit API is a library of functions and associated
%   structures, error codes and standard variable names
%   that implement the MUnit test framework.
%***


