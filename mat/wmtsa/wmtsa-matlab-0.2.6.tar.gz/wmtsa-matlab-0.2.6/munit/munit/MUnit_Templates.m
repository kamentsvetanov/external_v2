%****m* MUnit/Templates
%
% NAME
%   Template Files
%
% DESCRIPTION
%   MUnit template files:
%
%    * files: tsuite_template.m
%             tcase_template.m
%
%  
%***
