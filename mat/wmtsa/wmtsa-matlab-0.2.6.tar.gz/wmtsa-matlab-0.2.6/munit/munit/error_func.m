function error_func(number)
  
%  error('This is an error in error_func');


%  disp(number)
  
  error('MUNIT:TestError', 'This is a test error.');
  
  
return