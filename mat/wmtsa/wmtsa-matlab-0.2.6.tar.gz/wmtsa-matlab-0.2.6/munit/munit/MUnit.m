%****m* MUnit/0-Overview
%
% NAME
%   Overview
%
% DESCRIPTION
%   MUnit is a framework for unit testing of MATLAB functions.
%
% SEE ALSO
%   MUnit_Introduction, MUnit_Applications, MUnit_API, MUnit_Templates
%***

%****m* MUnit/munit
%***
