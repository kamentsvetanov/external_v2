function external_test(varargin)
% $Id: external_test.m 45 2004-11-17 03:55:41Z ccornish $
  test_name = mfilename;
  disp([test_name, ':  This is external test']);
return
